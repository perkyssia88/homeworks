# Ex_2
with open("tester.txt", encoding="utf-8") as t:
    num_lst = []
    str_lst = []
    for i in t.readlines():
        try:
            str_lst.append(i.replace("\n", ""))
        except:
            pass
    for i in str_lst:
        try:
            isinstance(int(i), int)
            num_lst.append(int(i))
            str_lst.remove(i)
        except:
            pass
    print(sorted(num_lst) + sorted(str_lst, key=len))